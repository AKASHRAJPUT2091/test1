module com.example.test1bakash {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.test1bakash to javafx.fxml;
    exports com.example.test1bakash;
}