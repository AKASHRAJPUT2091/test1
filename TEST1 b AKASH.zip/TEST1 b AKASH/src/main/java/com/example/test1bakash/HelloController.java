package com.example.test1bakash;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class HelloController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    private Model model = new Model();

    @FXML
    private void onHelloButtonClick() {

        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        System.out.println("Username entered: '" + username + "'");
        System.out.println("Password entered: '" + password + "'");

        if (model.isLockedOut()) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Login Blocked");
            alert.setHeaderText(null);
            alert.setContentText("You have been locked out due to too many failed attempts.");
            alert.showAndWait();
            return;
        }

        if (model.authenticate(username, password)) {
            Alert alert = new Alert(AlertType.INFORMATION);
            alert.setTitle("Login Successful");
            alert.setHeaderText(null);
            alert.setContentText("Welcome, " + username + "!");
            alert.showAndWait();

            model.resetAttempts();
        } else {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setTitle("Login Failed");
            alert.setHeaderText(null);
            alert.setContentText("Invalid username or password. " +
                    "Remaining attempts: " + model.getRemainingAttempts());
            alert.showAndWait();
        }
    }
}