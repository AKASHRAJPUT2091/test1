package com.example.test1bakash;

public class Model {

    private final String validUsername = "AkashAkash";
    private final String validPassword = "2091";

    private int maxAttempts = 5;

    private int remainingAttempts;

    public Model() {
        this.remainingAttempts = maxAttempts;
    }

    public boolean authenticate(String username, String password) {
        if (remainingAttempts > 0) {
            if (username.equals(validUsername) && password.equals(validPassword)) {
                return true;
            } else {
                remainingAttempts--;
                return false;
            }
        } else {
            return false;
        }
    }

    public int getRemainingAttempts() {
        return remainingAttempts;
    }

    public boolean isLockedOut() {
        return remainingAttempts <= 0;
    }

    public void resetAttempts() {
        this.remainingAttempts = maxAttempts;
    }
}
